import ObjectClass.UserClass;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

public class IHMSignin extends JFrame {
    // Constructor to set up the GUI
    public IHMSignin() throws MalformedURLException, NotBoundException, RemoteException {
        setTitle("TINBRI TOUNSI the Game:Sign-In ");
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setBackground(Color.BLACK);
        //setLayout(new BorderLayout());


        // setting icon
        Image icon =new ImageIcon(this.getClass().getResource("Image/logo-01 - Copy.png")).getImage();
        this.setIconImage(icon);


        JLayeredPane layeredPane = new JLayeredPane();
        layeredPane.setPreferredSize(new Dimension(800, 600));


        // Adding background
       /* ImageIcon BG = new ImageIcon(getClass().getResource("cover-01.png"));
        JLabel backgroundLabel = new JLabel(BG);
        backgroundLabel.setBounds(380, 50, 20,20);
        layeredPane.add(backgroundLabel, Integer.valueOf(0));*/

        //adding image

        ImageIcon i1 = new ImageIcon(this.getClass().getResource("Image/logo-01 - Copy.png"));
        Image i2 = i1.getImage().getScaledInstance(100,100,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(350,30,100,100);
        layeredPane.add(image , Integer.valueOf(1));


        // Create panels for text fields and buttons
        JPanel formPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        formPanel.setOpaque(false);  // Make the panel transparent

        // Username and password labels and text fields
        JLabel user = new JLabel("Username:");
        user.setForeground(Color.WHITE);
        user.setFont(new Font("Courier", Font.BOLD, 15));
        formPanel.add(user);

        JTextField usernameField = new JTextField(15);
        formPanel.add(usernameField);

        JLabel Pass = new JLabel("Password:");
        Pass.setForeground(Color.white);
        Pass.setFont(new Font("Courier", Font.BOLD, 15));
        formPanel.add(Pass);
        JPasswordField passwordField = new JPasswordField(15);
        formPanel.add(passwordField);

        // Buttons for submitting and resetting
        JButton submitButton = new JButton("Submit");
        JButton resetButton = new JButton("Reset");
        submitButton.setForeground(new Color(0xe5dacc));
        submitButton.setBackground(new Color(0x7c191b));
        submitButton.setFont(new Font("tahoma",Font.BOLD,15));
        resetButton.setBackground(new Color(0x7c191b));
        resetButton.setForeground(new Color(0xe5dacc));
        resetButton.setFont(new Font("tahoma",Font.BOLD,15));
        //Start.setForeground(new Color(0xe5dacc));
        //        Start.setBackground(new Color(0x7c191b));
        //        Start.setFont(new Font("tahoma",Font.BOLD,20));
        JButton ForgotPass = new JButton("Forgot Pass");
        JButton DontHaveaccount = new JButton("New here");
        ForgotPass.setForeground(new Color(0xe5dacc));
        ForgotPass.setBackground(new Color(0x7c191b));
        ForgotPass.setFont(new Font("tahoma",Font.BOLD,15));
        DontHaveaccount.setBackground(new Color(0x7c191b));
        DontHaveaccount.setForeground(new Color(0xe5dacc));
        DontHaveaccount.setFont(new Font("tahoma",Font.BOLD,15));



















        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Logic to handle login
                System.out.println("Username: " + usernameField.getText());
                // You should handle password with care in real applications
                System.out.println("Password: " + new String(passwordField.getPassword()));

                UserClass u = new UserClass(usernameField.getText(),new String(passwordField.getPassword()),"");
                System.out.println("pfogkkjdskf1");
                try{
                    System.out.println("Lancement sign in!");
                    String url="rmi://127.0.0.1:9001/user";
                    //System.out.println("pfogkkjdskf2");
                    DAOuser us = (DAOuser) Naming.lookup(url);
                    //System.out.println("pfogkkjdskf3");
                   // us.Ajouteruser(u);
                    if(us.Authentifier(u)){
                        JOptionPane.showMessageDialog(null, "mawjoud tfadhil");
                        Point location = getLocation();
                        JFrame signUpFrame = new IHMWelcoming(u);
                        signUpFrame.setLocation(location);
                        dispose();
                        System.out.println("mawjoud");
                    }else{
                        System.out.println("!mawjoud");
                        JOptionPane.showMessageDialog(null, "wrong username or password!");
                        usernameField.setText("");
                        passwordField.setText("");
                    }} catch (MalformedURLException e1) {
                    throw new RuntimeException(e1);
                } catch (NotBoundException e1) {
                    throw new RuntimeException(e1);
                } catch (RemoteException e1) {
                    throw new RuntimeException(e1);
                }
            }
        });

        resetButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Clear fields
                usernameField.setText("");
                passwordField.setText("");
            }
        });
        DontHaveaccount.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Point location = getLocation();

                JFrame signUpFrame = null;
                try {
                    signUpFrame = new IHMSignup();
                } catch (MalformedURLException ex) {
                    throw new RuntimeException(ex);
                } catch (NotBoundException ex) {
                    throw new RuntimeException(ex);
                } catch (RemoteException ex) {
                    throw new RuntimeException(ex);
                }
                signUpFrame.setLocation(location);
                dispose();
            }
        });

        formPanel.add(submitButton);
        formPanel.add(resetButton);
        formPanel.add(DontHaveaccount);
        formPanel.add(ForgotPass);
        // Add formPanel to backgroundLabel instead of frame directly
        formPanel.setBounds(250,200,300,150);
        layeredPane.add(formPanel,Integer.valueOf(2));


        // Add background label to JFrame
        getContentPane().add(layeredPane);

        // Center the window
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        try {
            new IHMSignin();
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        } catch (NotBoundException e) {
            throw new RuntimeException(e);
        } catch (RemoteException e) {
            throw new RuntimeException(e);
        }
    }

}
