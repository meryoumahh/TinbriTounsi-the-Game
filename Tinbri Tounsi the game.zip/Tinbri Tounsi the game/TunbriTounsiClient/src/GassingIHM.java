import ObjectClass.GameClass;
import ObjectClass.UserClass;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.util.Date;

public class GassingIHM extends JFrame {

    private JTextField guessField;
    private JTextArea messageArea;
    private int randomNumber;
    GameClass g;
    Connection c;
    public GassingIHM(GameClass u, Connection c) throws RemoteException {
        this.g =u;
        this.c=c;
        setTitle("Tinbri Tounsi : Guessing Game");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLayout(new BorderLayout());
        getContentPane().setBackground(Color.BLACK);
        setVisible(true);
        // Generate a random number between 1 and 100
        Image icon =new ImageIcon(this.getClass().getResource("Image/logo-01 - Copy.png")).getImage();
        this.setIconImage(icon);






        // Panel to hold the input field and send button
        JPanel inputPanel = new JPanel();
        guessField = new JTextField(10);
        JButton sendButton = new JButton("Send");
        sendButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent a) {
                try {
                    String message = guessField.getText().trim();
                    if (!message.isEmpty()) {
                        messageArea.append("You: " + message + "\n");
                        Socket s = new Socket("127.0.0.1", 9000);
                        System.out.println("Je suis client, je suis connecte");
                        String guess = guessField.getText();
                        PrintWriter out = new PrintWriter(s.getOutputStream(), true);
                        out.println(guess);
                        BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
                        messageArea.append("Server " + in.readLine() + "\n");
                    }
                } catch (UnknownHostException e) {
                    throw new RuntimeException(e);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                    guessField.setText("");
                }// checkGuess();//tab3ith lil server w server yraja3lik
                //joption panel congrats

        });
        inputPanel.add(guessField);
        inputPanel.add(sendButton);
        inputPanel.setOpaque(false);

        messageArea = new JTextArea();
        messageArea.setEditable(false);


        add(inputPanel, BorderLayout.NORTH);
        add(new JScrollPane(messageArea), BorderLayout.CENTER);

        DAOgameimplementation daogame= new DAOgameimplementation(c);
        daogame.AjoutGame(g);




    }}




   /* public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
           public void run() {
                new GassingIHM(new GameClass("","",0,1,new Date())).setVisible(true);
            }*/

