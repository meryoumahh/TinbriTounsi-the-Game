import ObjectClass.OrderClass;
import ObjectClass.UserClass;

import javax.swing.*;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.sql.ResultSet;

public interface DAOorder extends Remote {
    public int Ajouterorder(OrderClass o) throws RemoteException;
    public ResultSet RechercherOrder (UserClass u) throws RemoteException;

}
