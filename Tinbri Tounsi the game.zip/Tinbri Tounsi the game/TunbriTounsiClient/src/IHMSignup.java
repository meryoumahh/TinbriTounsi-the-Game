import ObjectClass.UserClass;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

public class IHMSignup extends JFrame {
    public IHMSignup() throws MalformedURLException, NotBoundException, RemoteException {
    setTitle("TINBRI TOUNSI the Game:Sign-Up ");
    setSize(800, 600);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    setResizable(false);
    getContentPane().setBackground(Color.BLACK);
    //setLayout(new BorderLayout());


    // setting icon
    Image icon =new ImageIcon(this.getClass().getResource("Image/logo-01 - Copy.png")).getImage();
        this.setIconImage(icon);


    JLayeredPane layeredPane = new JLayeredPane();
        layeredPane.setPreferredSize(new Dimension(800, 600));


    // Adding background
       /* ImageIcon BG = new ImageIcon(getClass().getResource("cover-01.png"));
        JLabel backgroundLabel = new JLabel(BG);
        backgroundLabel.setBounds(380, 50, 20,20);
        layeredPane.add(backgroundLabel, Integer.valueOf(0));*/

    //adding image

    ImageIcon i1 = new ImageIcon(this.getClass().getResource("Image/logo-01 - Copy.png"));
    Image i2 = i1.getImage().getScaledInstance(100,100,Image.SCALE_DEFAULT);
    ImageIcon i3 = new ImageIcon(i2);
    JLabel image = new JLabel(i3);
        image.setBounds(350,30,100,100);
        layeredPane.add(image , Integer.valueOf(1));

        JLabel text= new JLabel("Welcome to Tinbri Tounsi");
        text.setForeground(Color.WHITE);
        text.setFont(new Font("Courier",Font.BOLD,24));

        text.setBounds(250,100,600,100);
        layeredPane.add(text,Integer.valueOf(1));


    // Create panels for text fields and buttons
    JPanel formPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        formPanel.setOpaque(false);  // Make the panel transparent

    // Username and password labels and text fields
    JLabel user = new JLabel("Username:");
        user.setForeground(Color.WHITE);
        user.setFont(new Font("Courier", Font.BOLD, 15));
        formPanel.add(user);

    JTextField usernameField = new JTextField(15);
        formPanel.add(usernameField);

        JLabel email = new JLabel("Email:");
        email.setForeground(Color.white);
        email.setFont(new Font("Courier", Font.BOLD, 15));
        formPanel.add(email);
        JTextField emailfield = new JTextField(15);
        formPanel.add(emailfield);

    JLabel Pass = new JLabel("Password:");
        Pass.setForeground(Color.white);
        Pass.setFont(new Font("Courier", Font.BOLD, 15));
        formPanel.add(Pass);
    JPasswordField passwordField = new JPasswordField(15);
        formPanel.add(passwordField);

        JLabel conPass = new JLabel("Confirm Password:");
        conPass.setForeground(Color.white);
        conPass.setFont(new Font("Courier", Font.BOLD, 15));
        formPanel.add(conPass);
        JPasswordField conpasswordField = new JPasswordField(15);
        formPanel.add(conpasswordField);


    // Buttons for submitting and resetting
    JButton submitButton = new JButton("Submit");

        submitButton.setForeground(new Color(0xe5dacc));
        submitButton.setBackground(new Color(0x7c191b));
        submitButton.setFont(new Font("tahoma",Font.BOLD,15));



       /* submitButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            // Logic to handle login
            System.out.println("Username: " + usernameField.getText());
            // You should handle password with care in real applications
            System.out.println("Password: " + new String(passwordField.getPassword()));
        }
    });*/


        formPanel.add(submitButton);

    // Add formPanel to backgroundLabel instead of frame directly
        formPanel.setBounds(250,200,300,150);
        layeredPane.add(formPanel,Integer.valueOf(2));


    // Add background label to JFrame
    getContentPane().add(layeredPane);






    submitButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {

            try{
                String url="rmi://127.0.0.1:9001/user";
                UserClass u = new UserClass(usernameField.getText(),new String(passwordField.getPassword()),emailfield.getText());
                DAOuser du= (DAOuser) Naming.lookup(url);
                int i = du.Ajouteruser(u);
                    JOptionPane.showMessageDialog(null, "Ajout fait");
                    Point location = getLocation();

                    // Create a new frame for sign-up
                    JFrame signUpFrame = new IHMWelcoming(u);
                    signUpFrame.setLocation(location);
                    dispose();
                   } catch (MalformedURLException e1) {
                throw new RuntimeException(e1);
            } catch (NotBoundException e1) {
                throw new RuntimeException(e1);
            } catch (RemoteException e1) {
                throw new RuntimeException(e1);
            }

        }
    });

























    // Center the window
    setLocationRelativeTo(null);
    setVisible(true);
}

public static void main(String[] args) {
    try {
        new IHMSignup();
    } catch (MalformedURLException e) {
        throw new RuntimeException(e);
    } catch (NotBoundException e) {
        throw new RuntimeException(e);
    } catch (RemoteException e) {
        throw new RuntimeException(e);
    }
}
}


