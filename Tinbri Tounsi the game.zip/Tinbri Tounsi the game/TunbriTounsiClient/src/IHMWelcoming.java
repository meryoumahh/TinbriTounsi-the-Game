import Myconnection.Config;
import Myconnection.MyConnection;
import ObjectClass.UserClass;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.rmi.RemoteException;
import java.sql.Connection;


public class IHMWelcoming extends JFrame {
    UserClass u ;
    public IHMWelcoming(UserClass u) {
        this.u=u;
        Connection con;
        setTitle("TINBRI TOUNSI the Game");
        setSize(800, 600);
        setResizable(false);
        getContentPane().setBackground(Color.BLACK);


        //setting icon
        Image icon =new ImageIcon(this.getClass().getResource("Image/logo-01 - Copy.png")).getImage();
        this.setIconImage(icon);


        JLayeredPane layeredPane = new JLayeredPane();
        layeredPane.setPreferredSize(new Dimension(800, 600));

        //Setting background
        /*ImageIcon i1 = new ImageIcon(this.getClass().getResource("cover-01.png"));
        Image i2 = i1.getImage().getScaledInstance(600,600,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(300,300,600,600);
        add(image);*/
        ImageIcon i1 = new ImageIcon(this.getClass().getResource("Image/logo-01 - Copy.png"));
        Image i2 = i1.getImage().getScaledInstance(200,200,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(280, 150, 200,200);
        layeredPane.add(image, Integer.valueOf(0)); // Ajouter à la couche d'index 0

        //getContentPane().add(imagePanel);



        //initilizeComponents();

        //ajout text
        JLabel welcoming = new JLabel("WELCOME TO TINBRI TOUNSI",JLabel.CENTER);
        welcoming.setFont(new Font("tahoma",Font.BOLD,24));
        welcoming.setForeground(new Color(0x7c191b));
       // welcoming.setHorizontalAlignment(JLabel.CENTER);// Position et taille du titre
        //welcoming.setVerticalAlignment(JLabel.NORTH);
        layeredPane.add(welcoming, Integer.valueOf(1)); // Ajouter à la couche d'index 1
        welcoming.setBounds(90, 125, 600, 40);
        //ajout button

        JButton Start = new JButton("Start");
        Start.setForeground(new Color(0xe5dacc));
        Start.setBackground(new Color(0x7c191b));
        Start.setFont(new Font("tahoma",Font.BOLD,20));


        // Set the rounded border for the button
        Start.setBorder(null);
        //Start.setHorizontalAlignment(JButton.CENTER);
        Start.setBounds(345, 350, 100, 40); // Position et taille du bouton
        layeredPane.add(Start, Integer.valueOf(2));

        Start.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               Connection con = MyConnection.Getconnection(Config.url, Config.username, Config.password);

                Point location = getLocation();
                // Create a new frame for sign-up
                mainpage mainpage = null;
                try {
                    mainpage = new mainpage(u,con);
                } catch (RemoteException ex) {
                    throw new RuntimeException(ex);
                }
                mainpage.setLocation(location);
                dispose();
            }
        });











































        getContentPane().add(layeredPane, BorderLayout.CENTER);
        setVisible(true);

        //imagePanel.add(Weltotinbri);

        //createLayout();
        //addEventListeners();
    }

     public static void main(String[] args){
        new IHMWelcoming(new UserClass("mejda","h","hi"));
    }
}
