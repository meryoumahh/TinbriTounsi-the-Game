import ObjectClass.GameClass;
import ObjectClass.UserClass;

import javax.swing.*;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DAOgameimplementation implements DAOgame{

    Connection conn;

    protected DAOgameimplementation(Connection conn){
        super();
        this.conn=conn;
    }

    public ResultSet RechercherGame(UserClass u) throws RemoteException {
        String RechQuery = "SELECT id, item_id FROM gamess WHERE iduser = ?";
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = conn.prepareStatement(RechQuery);
            ps.setString(1, u.getUsername());
            // ps.setString(2, u.getPassword());
            rs = ps.executeQuery();
            System.out.println("done");
            return rs;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


    @Override
    public int AjoutGame( GameClass g) throws RemoteException {
        String req = "insert into gamess values(?, ?, ?, ?,?)";
        PreparedStatement ps = null;
        String id = g.getUsername()+ String.valueOf(g.getIditem());
        if (conn != null) {
            try {
                ps = conn.prepareStatement(req);
                ps.setString(1, id);
                ps.setString(2, g.getGuesses());
                ps.setFloat(3, g.getClose());
                ps.setInt(4,g.getIditem());
                ps.setString(5, g.getUsername());

            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
            try {
                return ps.executeUpdate();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }}else{
            return 0;
        }
    }



}
