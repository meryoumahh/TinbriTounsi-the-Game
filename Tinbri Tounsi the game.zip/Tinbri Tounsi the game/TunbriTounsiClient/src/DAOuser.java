import ObjectClass.UserClass;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface DAOuser extends Remote {
    public boolean Authentifier (UserClass u) throws RemoteException;
    public int Ajouteruser (UserClass u) throws RemoteException;
}
