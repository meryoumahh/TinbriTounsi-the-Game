package ObjectClass;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Date;

public class GameClass  {
    String username;
    String guesses;
    float close;
    int iditem;


    public GameClass(String username, String guesses, float close, int i, Date d) {
        this.username = username;
        this.guesses = guesses;
        this.close = close;
        this.iditem=i;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getGuesses() {
        return guesses;
    }

    public void setGuesses(String guesses) {
        this.guesses = guesses;
    }

    public float getClose() {
        return close;
    }

    public void setClose(float close) {
        this.close = close;
    }

    @Override
    public String toString() {
        return "Game{" +
                "username='" + username + '\'' +
                ", guesses=" + guesses +
                ", close=" + close +
                '}';
    }

    public int getIditem() {
        return iditem;
    }

    public void setIditem(int iditem) {
        this.iditem = iditem;
    }


}

