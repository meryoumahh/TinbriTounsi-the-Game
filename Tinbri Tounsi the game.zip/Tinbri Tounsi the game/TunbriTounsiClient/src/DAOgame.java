import ObjectClass.GameClass;
import ObjectClass.UserClass;

import javax.swing.*;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.sql.ResultSet;

public interface DAOgame extends Remote {
    public ResultSet RechercherGame(UserClass u) throws RemoteException;
    public int AjoutGame( GameClass g) throws RemoteException;
}
