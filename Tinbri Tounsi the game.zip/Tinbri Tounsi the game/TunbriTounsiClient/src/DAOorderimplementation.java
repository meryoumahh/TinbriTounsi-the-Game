import ObjectClass.OrderClass;
import ObjectClass.UserClass;

import javax.swing.*;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DAOorderimplementation  implements DAOorder {
    Connection conn;

    protected DAOorderimplementation(Connection conn) {
        super();
        this.conn=conn;
    }


    @Override
    public int Ajouterorder(OrderClass o) throws RemoteException {
        String req = "insert into orderss values(?, ?, ?,?)";
        PreparedStatement ps = null;
        String id = o.getUsername()+ String.valueOf(o.getIdItem());
        if (conn != null) {
            try {
                ps = conn.prepareStatement(req);
                ps.setString(1,id);
                ps.setString(2, o.getDate());
                ps.setInt(3, o.getIdItem());
                ps.setString(4,o.getUsername());
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
            try {
                return ps.executeUpdate();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }}else{
            return 0;
        }    }

    @Override
    public ResultSet RechercherOrder(UserClass u) throws RemoteException {
        String RechQuery = "SELECT id, item_id FROM orderss WHERE iduser = ?";
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = conn.prepareStatement(RechQuery);
            ps.setString(1, u.getUsername());
            // ps.setString(2, u.getPassword());
            rs = ps.executeQuery();
            System.out.println("done");
            return rs;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


}
