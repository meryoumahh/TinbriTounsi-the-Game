import ObjectClass.GameClass;
import ObjectClass.OrderClass;
import ObjectClass.UserClass;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.util.Date;

public class IHMAchatProd extends JFrame {
    UserClass u;
    Connection c;
    public IHMAchatProd(UserClass u, Connection c) {
        this.c=c;
        this.u=u;
        setTitle("TINBRI TOUNSI the Game:Our Products ");
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setBackground(Color.BLACK);
        int gap = 5;
        // setting icon
        Image icon =new ImageIcon(this.getClass().getResource("Image/logo-01 - Copy.png")).getImage();
        this.setIconImage(icon);


        ImageIcon i1 = new ImageIcon(this.getClass().getResource("Image/picc-01 - Copy.png"));
        Image i2 = i1.getImage().getScaledInstance(getWidth()/5,getHeight()/3,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel prod1 = new JLabel(i3);


        ImageIcon i4 = new ImageIcon(this.getClass().getResource("Image/pif-01 - Copy.png"));
        Image i5 = i4.getImage().getScaledInstance(getWidth()/5,getHeight()/3,Image.SCALE_DEFAULT);
        ImageIcon i6 = new ImageIcon(i5);
        JLabel prod2 = new JLabel(i6);

        ImageIcon i7 = new ImageIcon(this.getClass().getResource("Image/piiccii-01 - Copy.png"));
        Image i8 = i7.getImage().getScaledInstance(getWidth()/5,getHeight()/3,Image.SCALE_DEFAULT);
        ImageIcon i9 = new ImageIcon(i8);
        JLabel prod3 = new JLabel(i9);

        JButton Buy1 = new JButton("Get it!");
        JButton Buy2 = new JButton("Get it!");
        JButton Buy3 = new JButton("Get it!");

        /*Buy1.setPreferredSize(new Dimension(100, 30)); // Adjust the width and height as needed
        Buy2.setPreferredSize(new Dimension(100, 30)); // Adjust the width and height as needed
        Buy3.setPreferredSize(new Dimension(100, 30));*/

        JPanel panelprod1 = new JPanel();
        panelprod1.setLayout(new BoxLayout(panelprod1, BoxLayout.Y_AXIS));
        prod1.setBorder(BorderFactory.createEmptyBorder(gap, 0, gap, 0));
        Buy1.setBorder(BorderFactory.createEmptyBorder(gap, gap, gap, gap));
        prod1.setAlignmentX(Component.CENTER_ALIGNMENT);
        Buy1.setAlignmentX(Component.CENTER_ALIGNMENT);
        panelprod1.add(prod1);
        panelprod1.add(Buy1);
        panelprod1.setOpaque(false);


       // panelprod1.setPreferredSize(new Dimension(400,600));


        JPanel panelprod2 = new JPanel();
        panelprod2.setLayout(new BoxLayout(panelprod2, BoxLayout.Y_AXIS));
        prod2.setBorder(BorderFactory.createEmptyBorder(gap, 0, gap, 0));
        Buy2.setBorder(BorderFactory.createEmptyBorder(gap, gap, gap, gap));
        prod2.setAlignmentX(Component.CENTER_ALIGNMENT);
        Buy2.setAlignmentX(Component.CENTER_ALIGNMENT);
        panelprod2.add(prod2);
        panelprod2.add(Buy2);
        panelprod2.setOpaque(false);
       // panelprod2.setPreferredSize(new Dimension(400,600));

        JPanel panelprod3 = new JPanel();
        panelprod3.setLayout(new BoxLayout(panelprod3, BoxLayout.Y_AXIS));
        prod3.setBorder(BorderFactory.createEmptyBorder(gap, 0, gap, 0));
        Buy3.setBorder(BorderFactory.createEmptyBorder(gap, gap, gap, gap));
        prod3.setAlignmentX(Component.CENTER_ALIGNMENT);
        Buy3.setAlignmentX(Component.CENTER_ALIGNMENT);
        panelprod3.add(prod3);
        panelprod3.add(Buy3);
        panelprod3.setOpaque(false);
        //panelprod3.setPreferredSize(new Dimension(400,600));


        JPanel panelprods = new JPanel(new GridLayout(1,3,10,1));
        panelprods.setOpaque(false);
       // panelprods.setPreferredSize(new Dimension(600,600));

        panelprods.add(panelprod1);
        panelprods.add(panelprod2);
        panelprods.add(panelprod3);


        JLabel CYD= new JLabel("Choose Your Design!");
        CYD.setPreferredSize(new Dimension(800,100));
        CYD.setHorizontalAlignment(JLabel.CENTER);
        CYD.setVerticalAlignment((JLabel.CENTER));
        CYD.setFont(new Font("tahoma",Font.BOLD,24));
        CYD.setForeground(new Color(0x7c191b));


        JButton retn = new JButton("Back");
        //retn.setVerticalAlignment(JButton.RIGHT);
        JPanel btnr = new JPanel();
        btnr.add(retn,BorderLayout.SOUTH);
       // retn.setVerticalAlignment(JButton.SOUTH_EAST);
        retn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Point location = getLocation();

                // Create a new frame for sign-up
                JFrame signUpFrame = null;
                try {
                    signUpFrame = new mainpage(u,c);
                } catch (RemoteException ex) {
                    throw new RuntimeException(ex);
                }
                signUpFrame.setLocation(location);
                dispose();
            }
        });



        Buy1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                OrderClass or= new OrderClass(u.getUsername(),"",1);
                try{
                    DAOorderimplementation daorder = new DAOorderimplementation(c);
                    daorder.Ajouterorder(or);
                    GameClass g= null;
                    int choice = JOptionPane.showConfirmDialog(null, "Do you want to proceed?", "JOIN THE GAME", JOptionPane.YES_NO_OPTION);

                    if (choice == JOptionPane.YES_OPTION) {
                        g= new GameClass(u.getUsername(),"",0,1,new Date());
                        Point location = getLocation();
                        GassingIHM gg = new GassingIHM(g,c);
                    }else if (choice == JOptionPane.NO_OPTION){
                        g= null;

                    }

                } catch (RemoteException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });


        Buy2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                OrderClass or= new OrderClass(u.getUsername(),"",2);
                try{
                    DAOorderimplementation daorder = new DAOorderimplementation(c);
                    daorder.Ajouterorder(or);
                    GameClass g;
                    int choice = JOptionPane.showConfirmDialog(null, "Do you want to proceed?", "JOIN THE GAME", JOptionPane.YES_NO_OPTION);

                    if (choice == JOptionPane.YES_OPTION) {
                        g= new GameClass(u.getUsername(),"",0,2,new Date());
                        Point location = getLocation();
                        GassingIHM gg = new GassingIHM(g,c);
                    }else if (choice == JOptionPane.NO_OPTION){
                        g= null;
                    }

                } catch (RemoteException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });
        Buy3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                OrderClass or= new OrderClass(u.getUsername(),"",3);
                try{
                    DAOorderimplementation daorder = new DAOorderimplementation(c);
                    daorder.Ajouterorder(or);
                    GameClass g;
                    int choice = JOptionPane.showConfirmDialog(null, "Do you want to proceed?", "JOIN THE GAME", JOptionPane.YES_NO_OPTION);
                    if (choice == JOptionPane.YES_OPTION) {
                        g= new GameClass(u.getUsername(),"",0,3,new Date());
                        Point location = getLocation();
                        GassingIHM gg = new GassingIHM(g,c);
                    }else{
                        g=null;

                    }

                } catch (RemoteException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });




        getContentPane().add(panelprods,BorderLayout.CENTER);

        getContentPane().add(CYD,BorderLayout.NORTH);
        getContentPane().add(btnr,BorderLayout.SOUTH);
       // getContentPane().add(panelprod1);
        //getContentPane().add(panelprod2);
        setVisible(true);



    }
    /*public static void main(String[] args) {
        new IHMAchatProd(new UserClass("kl","oih","kjh"));
    }*/
}
