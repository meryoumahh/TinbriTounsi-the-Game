package Myconnection;

public class Config {
    public static final String url="jdbc:mysql://127.0.0.1/tinbritounsi2";
    public static final String username="root";
    public static final String password="";

}
