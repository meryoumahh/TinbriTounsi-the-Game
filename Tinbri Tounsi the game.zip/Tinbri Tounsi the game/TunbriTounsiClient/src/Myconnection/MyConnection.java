package Myconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyConnection {

    public static Connection Getconnection (String Url, String Username, String Password){
        //chargement Driver
        String nomDriver ="com.mysql.jdbc.Driver";
        try {
            Class.forName(nomDriver);
            System.out.println("La classe " + nomDriver + " est trouvée");
        } catch (ClassNotFoundException e) {
            System.out.println("La classe " + nomDriver + " n'a pas été trouvée" + e.getMessage());

        }

        //java sql
        Connection con = null;
        try {
            con = DriverManager.getConnection(Url, Username, Password);
            System.out.println("Connected....");
        } catch (SQLException e) {
            System.out.println("Erreur connection" + e.getMessage());
            return null;
        }
        return con;
    }
}
