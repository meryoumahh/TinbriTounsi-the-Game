import ObjectClass.UserClass;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.ResultSet;

public class mainpage extends JFrame {
    UserClass u;
    Connection c;
    public mainpage(UserClass u, Connection c) throws RemoteException {
        this.u=u;
        this.c=c;
        setTitle("TINBRI TOUNSI the Game");
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setBackground(Color.BLACK);
        setLayout(null);
        Image icon =new ImageIcon(this.getClass().getResource("Image/logo-01 - Copy.png")).getImage();
        this.setIconImage(icon);



        ImageIcon i1 = new ImageIcon(this.getClass().getResource("Image/logo-01 - Copy.png"));
        Image i2 = i1.getImage().getScaledInstance(100,100,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(350,15,100,100);
        getContentPane().add(image);

        JLabel dash =new JLabel("Dashboard");
        dash.setFont(new Font("tahoma",Font.BOLD,24));
        dash.setForeground(new Color(0x7c191b));
        dash.setBounds(340,100,600,100);
        getContentPane().add(dash);


        DAOorderimplementation daoo = new DAOorderimplementation(c);
        ResultSet rs = daoo.RechercherOrder(u);
       JTable jl2 = new JTable();

        JScrollPane scrollPane2 = new JScrollPane(jl2);
        scrollPane2.setBounds(100,200,300,200);
        MyTableModel model = new MyTableModel(rs);
        jl2.setModel(model);

        scrollPane2.setOpaque(false);
        getContentPane().add(scrollPane2);



        DAOgameimplementation daog = new DAOgameimplementation(c);
        ResultSet rsg = daog.RechercherGame(u);

        JTable jl1 = new JTable();
        JScrollPane scrollPane = new JScrollPane(jl1);
        scrollPane.setBounds(500,200,200,200);
       // MyTableModel model1 = new MyTableModel(rs);
        jl1.setModel(model);
        scrollPane.setOpaque(false);
        getContentPane().add(scrollPane);











       /* String colname = "My Games:";
        Object[][] data = {
                {"Game A"},
                {"Game B"},
                {"Game C"},
                {"Game D"},
                {"Game E"},
                {"Game B"},
                {"Game C"},
                {"Game D"},
                {"Game E"},
                {"Game B"},
                {"Game C"},
                {"Game D"},
                {"Game E"}
        };
        DefaultTableModel model = new DefaultTableModel(data, new Object[]{colname});

        JTable jl1 = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(jl1);
        scrollPane.setBounds(500,200,200,200);
        scrollPane.setOpaque(false);
        getContentPane().add(scrollPane);
*/

        JButton feedabck = new JButton("Feedback");
        feedabck.setBounds(600,500,150,40);
        feedabck.setBackground(new Color(0x7c191b));
        feedabck.setForeground(new Color(0xe5dacc));
        feedabck.setFont(new Font("tahoma",Font.BOLD,15));
        getContentPane().add(feedabck);

        JButton newpro = new JButton("View New Products");
        newpro.setBounds(40,500,200,40);
        newpro.setBackground(new Color(0x7c191b));
        newpro.setForeground(new Color(0xe5dacc));
        newpro.setFont(new Font("tahoma",Font.BOLD,15));
        getContentPane().add(newpro);

        newpro.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Point location = getLocation();

                // Create a new frame for sign-up
                JFrame signUpFrame = new IHMAchatProd(u, c);
                signUpFrame.setLocation(location);
                dispose();
            }
        });



        setVisible(true);
    }
    /*public static void main(String[] args) {
        new mainpage(new UserClass("hi","h","hi"),null);
    }*/}
