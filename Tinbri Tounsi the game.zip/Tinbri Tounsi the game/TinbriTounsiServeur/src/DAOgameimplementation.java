import ObjectClass.GameClass;
import ObjectClass.UserClass;

import javax.swing.*;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.*;

public class DAOgameimplementation extends UnicastRemoteObject implements DAOgame{

    Connection conn;

    protected DAOgameimplementation(Connection conn) throws RemoteException {
        super();
        this.conn=conn;
    }
    @Override
    public void RechercherGame(UserClass u, JFrame j) throws RemoteException {
        String RechQuery = "SELECT dates, item FROM orders WHERE id = ?";
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = conn.prepareStatement(RechQuery);
            ps.setString(1, u.getUsername());
            // ps.setString(2, u.getPassword());
            rs = ps.executeQuery();
            System.out.println("done");


            JTable jl2 = new JTable();
            JScrollPane scrollPane2 = new JScrollPane(jl2);
            scrollPane2.setBounds(100, 200, 300, 200);
            MyTableModel model = new MyTableModel(rs);
            scrollPane2.setOpaque(false);
            j.getContentPane().add(scrollPane2);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


    @Override
    public int AjoutGame( GameClass g) throws RemoteException {
        String req = "insert into orders values(?, ?, ?, ?)";
        PreparedStatement ps = null;
        if (conn != null) {
            try {
                ps = conn.prepareStatement(req);
                ps.setString(1, g.getUsername());
                ps.setString(2, g.getGuesses());
                ps.setFloat(3, g.getClose());
                ps.setInt(4,g.getIditem());

            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
            try {
                return ps.executeUpdate();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }}else{
            return 0;
        }
    }
}
