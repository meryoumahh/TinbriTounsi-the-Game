import ObjectClass.OrderClass;
import ObjectClass.UserClass;

import javax.swing.*;
import java.rmi.RemoteException;
import java.rmi.server.RMIClientSocketFactory;
import java.rmi.server.RMIServerSocketFactory;
import java.rmi.server.UnicastRemoteObject;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DAOorderimplementation extends UnicastRemoteObject implements DAOorder {
    Connection conn;

    protected DAOorderimplementation(Connection conn) throws RemoteException {
        super();
        this.conn=conn;
    }


    @Override
    public int Ajouterorder(OrderClass o) throws RemoteException {
        String req = "insert into orders values(?, ?, ?)";
        PreparedStatement ps = null;
        if (conn != null) {
            try {
                ps = conn.prepareStatement(req);
                ps.setString(1, o.getUsername());
                ps.setString(2, o.getDate());
                ps.setInt(3, o.getIdItem());
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
            try {
                return ps.executeUpdate();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }}else{
            return 0;
        }    }

    @Override
    public void RechercherOrder(UserClass u, JFrame j) throws RemoteException {
        String RechQuery = "SELECT dates, item FROM orders WHERE id = ?";
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = conn.prepareStatement(RechQuery);
            ps.setString(1, u.getUsername());
            // ps.setString(2, u.getPassword());
            rs = ps.executeQuery();
            System.out.println("done");


            JTable jl2 = new JTable();
            JScrollPane scrollPane2 = new JScrollPane(jl2);
            scrollPane2.setBounds(100,200,300,200);
            MyTableModel model = new MyTableModel(rs);
            scrollPane2.setOpaque(false);
           j.getContentPane().add(scrollPane2);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


}
