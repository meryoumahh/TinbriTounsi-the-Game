package ObjectClass;

import java.io.Serializable;
import java.util.Date;

public class OrderClass implements Serializable {
    String username;
    String date;
    int idItem;

    public OrderClass(String username, String date, int idItem) {
        this.username = username;
        this.date = date;
        this.idItem = idItem;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getIdItem() {
        return idItem;
    }

    public void setIdItem(int idItem) {
        this.idItem = idItem;
    }

    @Override
    public String toString() {
        return "Order{" +
                "username='" + username + '\'' +
                ", date=" + date +
                ", idItem=" + idItem +
                '}';
    }
}
