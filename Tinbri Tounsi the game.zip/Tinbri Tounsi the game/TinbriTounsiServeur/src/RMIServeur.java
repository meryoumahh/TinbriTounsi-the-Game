import MyConnection.Configuration;
import MyConnection.MyConnectionsetup;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.sql.Connection;

public class RMIServeur {
      public static void main(String[] args){
        Connection con = MyConnectionsetup.Getconnection(Configuration.url, Configuration.username, Configuration.password);
        try {
            DAOuser user = new DAOuserimplementation(con);
            DAOorder orders = new DAOorderimplementation(con);
            DAOgame games =new DAOgameimplementation(con);
            System.out.println("lancement serveur!");
            String url = "rmi://localhost:9001/user";
            //String url1 = "rmi://localhost:9001/orders";
            //String url2 = "rmi://localhost:9001/games";
            LocateRegistry.createRegistry(9001);
            System.out.println("Serveur en ecoute");
            Naming.rebind(url, user);
           // Naming.rebind(url1,orders);
            //Naming.rebind(url2,games);
            System.out.println("hiiiii");
        } catch (RemoteException e) {
            throw new RuntimeException(e);
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
    }
}
