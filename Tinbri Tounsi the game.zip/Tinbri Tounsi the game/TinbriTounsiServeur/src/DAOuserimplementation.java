import ObjectClass.UserClass;

import java.rmi.RemoteException;
import java.rmi.server.RMIClientSocketFactory;
import java.rmi.server.RMIServerSocketFactory;
import java.rmi.server.UnicastRemoteObject;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DAOuserimplementation extends UnicastRemoteObject implements DAOuser{

    Connection conn = null;

    public DAOuserimplementation(Connection conn) throws RemoteException {
        super();
        this.conn=conn;

    }

    protected DAOuserimplementation() throws RemoteException {
    }

    protected DAOuserimplementation(int port) throws RemoteException {
        super(port);
    }

    protected DAOuserimplementation(int port, RMIClientSocketFactory csf, RMIServerSocketFactory ssf) throws RemoteException {
        super(port, csf, ssf);
    }


    @Override
    public boolean Authentifier(UserClass u) throws RemoteException {
        String RechQuery = "SELECT * FROM Users WHERE id = ? AND password = ?";
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = conn.prepareStatement(RechQuery);
            ps.setString(1, u.getUsername());
            ps.setString(2, u.getPassword());
            rs = ps.executeQuery();
            System.out.println("hiiiiii");
            System.out.println("done");

            if (rs.next()) {
                return true;
            } else {
                return false;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public int Ajouteruser(UserClass u) throws RemoteException {
        String req = "insert into Users values(?, ?, ?)";
        PreparedStatement ps = null;
        if (conn != null) {
            try {
                ps = conn.prepareStatement(req);
                ps.setString(1, u.getUsername());
                ps.setString(2, u.getPassword());
                ps.setString(3, u.getEmail());
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
            try {
                return ps.executeUpdate();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }}else{
            return 0;
        }
    }
}