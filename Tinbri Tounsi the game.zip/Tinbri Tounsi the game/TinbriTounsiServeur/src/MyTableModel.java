import javax.swing.table.AbstractTableModel;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

public class MyTableModel extends AbstractTableModel {
    ResultSetMetaData rsmd;
    ArrayList<Object[]> data=new ArrayList<Object[]>();

    MyTableModel(ResultSet rs){
        try {
            rsmd=rs.getMetaData();
            while (rs.next()){
                Object[]ligne=new Object[rsmd.getColumnCount()];
                for(int i=0;i<ligne.length;i++){
                    ligne[i]=rs.getObject(i+1);
                }
                data.add(ligne);
            }
        } catch (SQLException e) {

        }


    }
    @Override
    public int getRowCount() {
        return data.size();
    }

    @Override
    public int getColumnCount() {
        try {
            return rsmd.getColumnCount();
        } catch (SQLException e) {
            return 0;
        }
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        return data.get(rowIndex)[columnIndex];

    }
    public String getColumnName(int column){
        try {
            return rsmd.getColumnName(column+1);
        } catch (SQLException e) {
            return null;
        }
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        if(getColumnName(columnIndex).equalsIgnoreCase("cin"))
            return false;
        else
            return true;

    }
    int columnNameToIndex(String columnName){
        for(int i=0;i<getColumnCount();i++){
            if(getColumnName(i).equalsIgnoreCase(columnName))
                return i;
        }
        return -1;
    }




}

